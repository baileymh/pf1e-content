People and credit are listed in no particular order.

# Mike Chopswil
* csv data for [Feats](https://docs.google.com/spreadsheets/d/1psJ7mzGS9cLpIVhvo2iwGggr2WMU_TgbXaueVGg9HJk/edit#gid=99619603), [Spells](https://docs.google.com/spreadsheets/d/119pUkuASdLBuAfNpQsk2G69Qd2rM0_sG50vNYLeRNSA/edit#gid=1003071054), [Afflications](https://docs.google.com/spreadsheets/d/1UZPevl9F50sOeug_-B16o-iT1HjwVUQiEVE_iP8oqYk/edit#gid=1102210427), and [Magic Items](https://docs.google.com/spreadsheets/d/1A5s--mNlyehCTdcT3dz5JEKztPr2KenN4-2g1KeGJNk/edit#gid=44940957)

# Blahness98
* [Classes/Archetypes](https://www.fantasygrounds.com/forums/showthread.php?50404-Class-and-Archetype-Module) (none currently added)
* [Spells](https://www.fantasygrounds.com/forums/showthread.php?58962-PFRPG-Spellbook) (none currently added


## https://game-icons.net/
For providing an excellent resource for making free customized icons.
The icons used from their site can be accredited to the following artists:

* DarkZaitzev (https://www.deviantart.com/darkzaitzev) under CC BY 3.0

* Delapouite (https://delapouite.com/) under CC BY 3.0

* GeneralAce135 under CC BY 3.0

* Lorc (https://lorcblog.blogspot.com/) under CC BY 3.0

* Skoll under CC BY 3.0

# Esalarc
* [Traits](https://www.fantasygrounds.com/forums/showthread.php?17935-Pathfinder-Feats-Traits-and-Equipment)

# dllewell
* [Kingdom Building](https://www.fantasygrounds.com/forums/showthread.php?62363-Module-for-Kingdom-Building) (not currently added)

# Raabb
* added images to feats, found missing entries

# Kronos
* Helped with Feats. Found and created all missing entries for traits. Created buffs database. Contributed time and energy for deities, and generally helped with various aspects.

# llneo12 
* added images to feats, and helped with linking prestige classes
